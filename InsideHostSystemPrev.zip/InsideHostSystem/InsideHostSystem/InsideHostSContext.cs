/* az EF megold�shoz kellett volna*/

//namespace InsideHostSystem
//{
//    using System;
//    using System.Data.Entity;
//    using System.ComponentModel.DataAnnotations.Schema;
//    using System.Linq;

//    public partial class InsideHostSContext : DbContext
//    {
//        public InsideHostSContext()
//            : base("name=TestDB")
//        {
//                  }

//        public  DbSet<Inventory> Inventory { get; set; }
//        public  DbSet<Member> Members { get; set; }
//        public  DbSet<Message> Messages { get; set; }

//        protected override void OnModelCreating(DbModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<Member>().ToTable("Member");
//        }
//    }
//}
