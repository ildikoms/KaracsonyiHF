﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace InsideHostSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // InsideHostSContext context = new InsideHostSContext();
        DBConnect dBConnect = new DBConnect();
        public MainWindow()
        {
            InitializeComponent();
            /* //EF megoldás lenne
            context.Database.CreateIfNotExists();*/

            //feltölti adatbázisból a listát
            Member.AllMembers = dBConnect.ListMembers(dBConnect.BuildSelectQuery());
        }


        private void regButton_Click(object sender, RoutedEventArgs e)
        {
            regFeedBack.Text = "";
            if (regName.Text == "" || regPass.Password == "")
            {
                regFeedBack.Text = "A felhasználónév vagy a jelszó mező nem maradhat üres!";
                return;
            }

            if (regCheckBox.IsChecked == false)
            {
                regFeedBack.Text = "A használati feltételeket el kell fogadni!";
                return;
            }

            string name = regName.Text;
            string pass = regPass.Password;

            if (pass.Length >= 6)
            {
                foreach (var member in Member.AllMembers)
                {
                    if (member.Name == name)
                    {
                        regFeedBack.Text = "Ezzel a névvel már regisztráltak, válassz mást!";
                        regName.Text = "";
                        regPass.Password = "";
                        return;
                    }

                }
                Member.AllMembers.Add(new Member(name, pass));
                /* //EF megoldás lenne
                 context.Members.Add(new Member(name, pass));
                 context.SaveChanges();*/

                dBConnect.Insert(dBConnect.BuildInsertQuery("Member", name, pass));
                regFeedBack.Text = "Sikeres Regisztráció! Most már be tudsz jelentkezni!";
                regName.Text = "";
                regPass.Password = "";
            }
            else
            {
                regFeedBack.Text = "Túl rövid jelszó! Adj meg legalább 6 karaktert!";
            }
            //logFeedBack.Text = $"{MySystem.Members.Count}";
        }

        private void logButton_Click(object sender, RoutedEventArgs e)
        {
            logFeedBack.Text = "";
            if (logName.Text == "" || logPass.Password == "")
            {
                regFeedBack.Text = "A felhasználónév vagy a jelszó mező nem maradhat üres!";
                return;
            }

            string name = logName.Text;
            string pass = logPass.Password;

            foreach (var member in Member.AllMembers)
            {
                if (member.Name == name && member.Pass == pass)
                {
                    //member.LogedIn = true;
                    new MemberProfile(member).Show();
                    logName.Text = "";
                    logPass.Password = "";
                    return;
                }
            }
            logFeedBack.Text = "Hibás felhasználónév vagy jelszó!";
        }
    }
}
