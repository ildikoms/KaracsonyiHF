﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace InsideHostSystem
{
    public partial class MemberProfile : Window
    {
        DBConnect dBConnect = new DBConnect();
        public Member Member { get; set; }
        public static List<MemberProfile> AllProfiles {get; set;}

        static MemberProfile()
        {
            AllProfiles = new List<MemberProfile>();
        }

        public MemberProfile(Member member)
        {
            AllProfiles.Add(this);
            Member = member;
            InitializeComponent();
            Member.LogedIn = true;
            MemberName.Text = Member.Name;
            Member.Contacts= dBConnect.ListMembers(dBConnect.BuildSelectQuery(Member.Name, 1));
            Member.Requests = dBConnect.ListMembers(dBConnect.BuildSelectQuery(Member.Name, 0));
            Member.Messages = dBConnect.ListMessages(dBConnect.BuildSelectQuery(Member.Name));
            ShowContacts();
            ShowNotContactedYet();
            FuggoFelkeresek(Member);
            NewMessage(Member);
            
        }

        //FELADAT: Ezt lehetne inkább Combo Box-szal megoldani h szebb legyen..
        private void ShowContacts()
        {
            Contacts.Text = "";
            foreach (var item in Member.Contacts)
            {
                Contacts.Text += item.Name + "\n";
            }
        }

        //FELADAT: Ezt is lehetne Combo Box-szal h szebb legyen..
        private void ShowNotContactedYet()
        {
            foreach (var item in Member.AllMembers)
            {
                if( item.Name != Member.Name && !Contacts.Text.Split().Contains(item.Name))
                    NotContactedYet.Text += item.Name + "\n";
            }
        }

        //Üzenetküldés
        private void Send_Click(object sender, RoutedEventArgs e)
        {
            if(MessageContent.Text == "")
            {
                MessageBox.Show("Üres üzenetet nem küldhetsz te béna...");
                return;
            }

            foreach (var tomember in Member.Contacts)
            {
                if(tomember.Name == MailTo.Text)
                {
                    tomember.Messages.Push(new Message(Member, DateTime.Now, MessageContent.Text));
                    if(tomember.LogedIn == true)
                    {
                        MemberProfile to = AllProfiles.Where(p => p.Member == tomember).First();
                        to.MessageContent.Text = "Olvasatlan üzenetei vannak!";
                    }
                    dBConnect.Insert(dBConnect.BuildInsertQuery("Message", DateTime.Now, this.Member.Name, MailTo.Text, MessageContent.Text));
                    MessageContent.Text = "";
                    MailTo.Text = "";
                    break;
                }
                MessageBox.Show("Ez a Member nincs az ismerőseid között!");
            }
        }

        //Kidobálja MessageBoxban az új üziket majd azok státuszát olvasottra váltja
        private void Unseen_Click(object sender, RoutedEventArgs e)
        {
            List<Message> query = Member.Messages.Where(m => m.Seen == false).ToList();
            if(query != null)
            {
                foreach (var item in query)
                {
                    MessageBox.Show($"{item.From.Name}\n{item.Date}\n\n{item.Content}");
                    item.Seen = true;
                    dBConnect.Update(dBConnect.BuildUpdateQuery("Message", item.Date, item.From.Name, this.Member.Name, item.Content));
                }
                MessageContent.Text = "";
            }
        }

        //FELADAT BELÜL, Ez írja ki ha vannak új üzenetek
        public void NewMessage(Member actual)
        {
            foreach (var message in actual.Messages)//ezt meg lehetne irni lambdásan csak ne dobjon Exceptiont ha nincs találat!!!
            {
                if (message.Seen == false)
                {
                    MessageContent.Text = "Olvasatlan üzenetei vannak!";
                }
            }
        }

        //Ez írja ki ha vannak függőben lévő felkérések
        public void FuggoFelkeresek(Member actual)
        {
            if (actual.Requests.Count != 0)
                NewContact.Text = "Függőben levő felkérései vannak!";
        }

        //Új member felvétele
        private void AddToContacts_Click(object sender, RoutedEventArgs e)
        {
            foreach (var member in Member.AllMembers)
            {
                if (member.Name == NewContact.Text)
                {
                    member.Requests.Add(Member);//ha nincs bejelentkezve, amikor bejelentkezik lefut a FuggoFelkeresek(önmaga)
                    dBConnect.Insert(dBConnect.BuildInsertQuery("Connections",0, Member.Name, NewContact.Text));
                    if (member.LogedIn == true)//ha be van jelentkezve
                    {
                        MemberProfile to = AllProfiles.Where(p => p.Member == member).First();
                        to.FuggoFelkeresek(member);
                    }
                    break;
                }
            }
            NewContact.Text = "";
        }
        
        //Ez ami a konkrét messageBoxot dobja
        public void RequestShowInMessageBox(Member member)
        {
            {
                MessageBoxResult result = MessageBox.Show($"{member.Name} ismerősnek jelölt!", "Új Felkérés", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    Member.Contacts.Add(member);
                    member.Contacts.Add(Member);                 
                    ShowContacts();
                }
            }
        }

        //Ez fut le a Felkérések gomb megnyomásakor
        private void Requests_Click(object sender, RoutedEventArgs e)
        {
            if(Member.Requests.Count != 0)
            {
                foreach (var member in Member.Requests)
                {
                    MessageBoxResult result = MessageBox.Show($"{member.Name} ismerősnek jelölt!", "Új Felkérés", MessageBoxButton.YesNo);
                    if (result == MessageBoxResult.Yes)
                    {
                        Member.Contacts.Add(member);
                        member.Contacts.Add(Member);
                        dBConnect.Insert(dBConnect.BuildInsertQuery("Connections", 1, Member.Name, member.Name));
                        dBConnect.Update(dBConnect.BuildUpdateQuery("Connections", Member.Name, member.Name));
                        ShowContacts();
                    }
                }
                Member.Requests.Clear();//ez kiüríti a listát, nem csak azt kéne törölni, akit visszaigazoltunk?
                NewContact.Text = "";
                NotContactedYet.Text = "";
                ShowNotContactedYet();
            }
        }

        //Ha zárjuk az ablakot FELADAT: legyne kilépés gomb ami ugyanezt hívja
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Member.LogedIn = false;
        }
    }
}
