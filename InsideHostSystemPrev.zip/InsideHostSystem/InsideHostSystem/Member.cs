﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace InsideHostSystem
{
    /* //EF megoldás lenne
   [Table("Member")]*/
    public class Member
    {  
        /* //EF megoldás lenne  
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]*/
        public int Id { get; set; }
        public string Name { get; private set; }
        public string Pass { get; private set; }

        /* //EF megoldás lenne
       [NotMapped()]*/
        public static List<Member> AllMembers { get; set; }
        public bool LogedIn { get; set; }
        public List<Member> Contacts { get; set; }
        public List<Member> Requests { get; set; }
        public Stack<Message> Messages { get; set; } //Azért Stack mert mindig az utolsónak kapottat akarom az első helyen látni

        static Member()
        {
            /*Már nem kell, mert a MainWindow konstruktorában feltöltöm az adatbázisból*/
            // AllMembers = new List<Member>();
        }

        public Member(string name, string pass)
        {
            Name = name;
            Pass = pass;
            Contacts = new List<Member>();
            Requests = new List<Member>();
            Messages = new Stack<Message>();
        }
    }
}
